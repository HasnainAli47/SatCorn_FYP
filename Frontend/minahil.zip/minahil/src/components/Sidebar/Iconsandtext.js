// import Sidebar, { SidebarItem } from "./Sidebar";
// import {
//   LifeBuoy,
//   Receipt,
//   Boxes,
//   Package,
//   UserCircle,
//   BarChart3,
//   LayoutDashboard,
//   Settings,
// } from "lucide-react";

// import React from "react";

// const Iconsandtext = () => {
//   return (
//     <main className="App">
//       <Sidebar>
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} alert />
//         <SidebarItem icon={<UserCircle size={20} />} text={"Users"} active />
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} active />
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} active />
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} active />
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} active />
//         <SidebarItem icon={<BarChart3 size={20} />} text={"Dashboard"} active />
//       </Sidebar>
//     </main>
//   );
// };

// export default Iconsandtext;
