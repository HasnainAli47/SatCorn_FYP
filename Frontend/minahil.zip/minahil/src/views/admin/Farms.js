import React from "react";
import Farmform from "components/Farm/Farmform.js";
import GopMap from "components/Farm/GoMap";

const Farms = () => {
  return (
    <>
      {/* <Farmform /> */}
      <GopMap />
    </>
  );
};

export default Farms;
