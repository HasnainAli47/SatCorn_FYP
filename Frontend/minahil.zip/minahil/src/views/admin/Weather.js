import React from "react";

// components

export default function Weather() {
  return (
    <>
      <h1>..................weather</h1>
    </>
  );
}
