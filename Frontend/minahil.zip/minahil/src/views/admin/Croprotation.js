import React from "react";

const Croprotation = () => {
  return <div>Croprotation</div>;
};

export default Croprotation;
